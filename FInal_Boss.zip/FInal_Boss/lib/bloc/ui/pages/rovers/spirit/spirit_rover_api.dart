import 'package:flutter/material.dart';

// SpiritRover representa la vista del rover Spirit.
class SpiritRover extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Inserta aquí el contenido para la página SpiritRover.
    return Center(child: Text('Contenido de Spirit Rover'));
  }
}