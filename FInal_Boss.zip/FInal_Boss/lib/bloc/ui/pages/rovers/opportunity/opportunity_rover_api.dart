import 'package:flutter/material.dart';

// OpportunityRover representa la vista del rover Opportunity.
class OpportunityRover extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Inserta aquí el contenido para la página OpportunityRover.
    return Center(child: Text('Contenido de Opportunity Rover'));
  }
}