package com.example.final_boss;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
